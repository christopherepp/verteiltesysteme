# python pip install 
# python main.py
apt-get update
pip install --upgrade setuptools
python -m pip install --upgrade pip
pip install flask
pip install flask-restplus
pip install werkzeug