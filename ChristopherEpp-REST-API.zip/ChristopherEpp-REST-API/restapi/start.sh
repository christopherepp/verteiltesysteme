# docker container exec -it christopherepp-rest-api-online /bin/bash
# service mysql start
# mysqladmin -u root create restapi
# mysqld_safe --skip-grant-tables
# python manage.py migrate auth
# python manage.py migrate sessions
# python manage.py migrate
# ./createdjangopassword.exp
# python manage.py runserver
# python manage.py startapp restapiApp
# pip3 install flask
# pip3 install flask-restplus